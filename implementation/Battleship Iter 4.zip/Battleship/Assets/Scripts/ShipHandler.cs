﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipHandler : MonoBehaviour {

    public bool shipAlive;

    void Start () {
        shipAlive = true;
    }
}
