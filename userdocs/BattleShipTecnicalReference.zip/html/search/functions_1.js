var searchData=
[
  ['cellhandler',['CellHandler',['../class_cell_handler.html#ad3dc64fc63614afa1ce64389530a15cd',1,'CellHandler']]]
];
