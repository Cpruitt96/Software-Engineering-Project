var searchData=
[
  ['boardhandler',['BoardHandler',['../class_board_handler.html',1,'']]]
];
