var searchData=
[
  ['none',['NONE',['../_game_controller_8cs.html#aa3041ae4242c0dd57a126d17505443b2ab50339a10e1de285ac99d4c3990b8693',1,'GameController.cs']]],
  ['numships',['numShips',['../class_turn_manager.html#a701c35ab04259ed80023858f5b619643',1,'TurnManager']]]
];
