var searchData=
[
  ['turnmanager',['TurnManager',['../class_turn_manager.html',1,'']]]
];
