var searchData=
[
  ['restart',['restart',['../class_game_controller.html#a8e51d0248bdf92dbed5980c448063562',1,'GameController']]]
];
