var indexSectionsWithContent =
{
  0: "abcefghimnpqrstwxy",
  1: "bcgmst",
  2: "a",
  3: "bcgmst",
  4: "acipqrs",
  5: "abcghmnpswxy",
  6: "gmp",
  7: "efmnp",
  8: "gm",
  9: "cr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

