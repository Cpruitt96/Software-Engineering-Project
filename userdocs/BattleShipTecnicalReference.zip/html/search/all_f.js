var searchData=
[
  ['wintext',['winText',['../class_turn_manager.html#ac866ea19ea2dadcee2d9bcf87c2ef5ba',1,'TurnManager']]]
];
