var searchData=
[
  ['cell',['cell',['../class_board_handler.html#a6a3eeaf9150a6a05fa2b9b0b2c239f6b',1,'BoardHandler']]],
  ['currentplayer',['currentPlayer',['../class_board_handler.html#ad3566696f1d3a5b4a1564c2e6b179cbb',1,'BoardHandler.currentPlayer()'],['../class_turn_manager.html#a5a5a81133a458c22c2f40ee267747b27',1,'TurnManager.currentPlayer()']]]
];
