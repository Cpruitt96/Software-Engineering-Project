var searchData=
[
  ['ship',['ship',['../class_turn_manager.html#ae9d14bdcc4dd38c5b84f9602b4d3f5dd',1,'TurnManager']]],
  ['shipalive',['shipAlive',['../class_ship_handler.html#ac1c330f11be6fb3ce6b7759a33a4344d',1,'ShipHandler']]],
  ['shipsremaining',['shipsRemaining',['../class_turn_manager.html#a6bb21e881498e9d54d66513fa3aec924',1,'TurnManager']]]
];
