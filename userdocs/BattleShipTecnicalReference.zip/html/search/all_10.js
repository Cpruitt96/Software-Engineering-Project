var searchData=
[
  ['xvalue',['xValue',['../class_cell_handler.html#a226115345f358384998fb99fde5dfdbf',1,'CellHandler']]]
];
