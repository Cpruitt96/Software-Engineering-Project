var searchData=
[
  ['numships',['numShips',['../class_turn_manager.html#a701c35ab04259ed80023858f5b619643',1,'TurnManager']]]
];
