var searchData=
[
  ['reset',['reset',['../class_game_controller.html#a33d38714e7a5a63e98d93f4cf3bec387',1,'GameController']]]
];
