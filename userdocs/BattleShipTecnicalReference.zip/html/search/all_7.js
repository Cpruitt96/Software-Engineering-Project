var searchData=
[
  ['isattackable',['isAttackable',['../class_board_handler.html#aecb8ffd7b2c2cd6d0f57a9ad85f3a275',1,'BoardHandler']]],
  ['isonboard',['isOnBoard',['../class_board_handler.html#af9fb1709f04b7c9c3bd12c2e9f3d6062',1,'BoardHandler']]],
  ['isplaceable',['isPlaceable',['../class_board_handler.html#ac58739a887e9b639d939a107ba414fc7',1,'BoardHandler']]]
];
