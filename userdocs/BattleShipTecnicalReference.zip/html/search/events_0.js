var searchData=
[
  ['changegamestate',['changeGameState',['../class_game_controller.html#a56df7f1f74f192f7f606619c2c058cbe',1,'GameController']]],
  ['changemenu',['changeMenu',['../class_game_controller.html#a6a26a2cb489f4e109542c1a17cf4adb3',1,'GameController']]]
];
