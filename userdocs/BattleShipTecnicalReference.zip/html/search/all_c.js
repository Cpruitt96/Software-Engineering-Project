var searchData=
[
  ['reset',['reset',['../class_game_controller.html#a33d38714e7a5a63e98d93f4cf3bec387',1,'GameController']]],
  ['restart',['restart',['../class_game_controller.html#a8e51d0248bdf92dbed5980c448063562',1,'GameController']]]
];
