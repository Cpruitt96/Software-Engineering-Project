var searchData=
[
  ['switchtoend',['switchToEnd',['../class_game_controller.html#a3e6f9d1f58eac89458ebed969ba164ab',1,'GameController']]],
  ['switchtomenu',['switchToMenu',['../class_game_controller.html#a059a3b40a8ab32c4621d5f28a423069a',1,'GameController.switchToMenu()'],['../class_game_controller.html#af12883e2418154e1b787744fbb418d54',1,'GameController.switchToMenu(MenuState newMenu)']]],
  ['switchtoplaying',['switchToPlaying',['../class_game_controller.html#a1ecf7c34eec7f2e0d22abcb515c72e23',1,'GameController']]]
];
