var searchData=
[
  ['cell',['cell',['../class_board_handler.html#a6a3eeaf9150a6a05fa2b9b0b2c239f6b',1,'BoardHandler']]],
  ['cellhandler',['CellHandler',['../class_cell_handler.html',1,'CellHandler'],['../class_cell_handler.html#ad3dc64fc63614afa1ce64389530a15cd',1,'CellHandler.CellHandler()']]],
  ['cellhandler_2ecs',['CellHandler.cs',['../_cell_handler_8cs.html',1,'']]],
  ['changegamestate',['changeGameState',['../class_game_controller.html#a56df7f1f74f192f7f606619c2c058cbe',1,'GameController']]],
  ['changemenu',['changeMenu',['../class_game_controller.html#a6a26a2cb489f4e109542c1a17cf4adb3',1,'GameController']]],
  ['class1',['Class1',['../class_assets_1_1_scripts_1_1_class1.html',1,'Assets::Scripts']]],
  ['class1_2ecs',['Class1.cs',['../_class1_8cs.html',1,'']]],
  ['currentplayer',['currentPlayer',['../class_board_handler.html#ad3566696f1d3a5b4a1564c2e6b179cbb',1,'BoardHandler.currentPlayer()'],['../class_turn_manager.html#a5a5a81133a458c22c2f40ee267747b27',1,'TurnManager.currentPlayer()']]]
];
