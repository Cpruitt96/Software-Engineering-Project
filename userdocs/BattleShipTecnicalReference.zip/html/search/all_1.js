var searchData=
[
  ['boardhandler',['BoardHandler',['../class_board_handler.html',1,'']]],
  ['boardhandler_2ecs',['BoardHandler.cs',['../_board_handler_8cs.html',1,'']]],
  ['boards',['boards',['../class_board_handler.html#a6f73449f879c6c09c1414091674e77fa',1,'BoardHandler']]],
  ['boardsize',['boardSize',['../class_board_handler.html#a5c0db8091965467b0c490292d17053d8',1,'BoardHandler']]]
];
