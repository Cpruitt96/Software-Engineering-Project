var searchData=
[
  ['turnmanager_2ecs',['TurnManager.cs',['../_turn_manager_8cs.html',1,'']]]
];
