var searchData=
[
  ['ship',['ship',['../class_turn_manager.html#ae9d14bdcc4dd38c5b84f9602b4d3f5dd',1,'TurnManager']]],
  ['shipalive',['shipAlive',['../class_ship_handler.html#ac1c330f11be6fb3ce6b7759a33a4344d',1,'ShipHandler']]],
  ['shiphandler',['ShipHandler',['../class_ship_handler.html',1,'']]],
  ['shiphandler_2ecs',['ShipHandler.cs',['../_ship_handler_8cs.html',1,'']]],
  ['shipplacement',['ShipPlacement',['../class_ship_placement.html',1,'']]],
  ['shipplacement_2ecs',['ShipPlacement.cs',['../_ship_placement_8cs.html',1,'']]],
  ['shipsremaining',['shipsRemaining',['../class_turn_manager.html#a6bb21e881498e9d54d66513fa3aec924',1,'TurnManager']]],
  ['switchtoend',['switchToEnd',['../class_game_controller.html#a3e6f9d1f58eac89458ebed969ba164ab',1,'GameController']]],
  ['switchtomenu',['switchToMenu',['../class_game_controller.html#a059a3b40a8ab32c4621d5f28a423069a',1,'GameController.switchToMenu()'],['../class_game_controller.html#af12883e2418154e1b787744fbb418d54',1,'GameController.switchToMenu(MenuState newMenu)']]],
  ['switchtoplaying',['switchToPlaying',['../class_game_controller.html#a1ecf7c34eec7f2e0d22abcb515c72e23',1,'GameController']]]
];
