var searchData=
[
  ['turnmanager',['TurnManager',['../class_turn_manager.html',1,'']]],
  ['turnmanager_2ecs',['TurnManager.cs',['../_turn_manager_8cs.html',1,'']]]
];
